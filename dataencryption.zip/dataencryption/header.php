<?php
date_default_timezone_set('America/New_York');
include_once('functions.php');
?>
<html>
<head>
<title>PHP ENCRYPTION DECRYPTION MYSQL</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
</head>
<body>
<?php include_once('menu.php'); ?>
<div class="jumbotron"><h1 class="text-center">The Best PHP Encryption Tutorial</h1>
</div>
<div class="container">
 <div class="row">
 <div class="col-sm-3"></div>
 <div class="col-sm-6">